# Ascend Tiling Visualizer MCP 用户安装说明

适用环境：macOS 上的 Codex Desktop、Codex CLI 或 Codex IDE 扩展。

## 安装前

管理员会单独给你一个以 `atv_` 开头的个人 Token。每个人的 Token 都不同，请勿转发、截图、粘贴到聊天中或提交到代码仓库。

## 安装

1. 解压管理员提供的安装包。
2. 双击 `setup-ascend-tiling-mcp-macos.command`。
3. 出现钥匙串密码提示后，粘贴个人 Token 并按回车。输入时不会显示字符。
4. 等待窗口显示四个 `✓`。
5. 使用 `Command + Q` 完全退出 Codex，然后重新打开并新建任务。

如果 macOS 阻止首次打开，请右键点击安装程序，选择“打开”。不要关闭系统的安全防护，也不要运行来源不明的修改版安装程序。

## 测试提示词

```text
请只使用 MCP 服务器 ascend_tiling_visualizer_cloud，实际调用它的 visualize_ascend_tiling 工具。不要使用本地的 ascend-tiling-visualizer。

请用以下输入生成 Tiling 可视化：
sources:
- role: kernel
  language: ascendc
  content: |
    auto offset = GetBlockIdx() * blockLength;
    DataCopy(xLocal, xGm[offset], tileLength);
    Add(y, x, z, tileLength);

context:
  tilingValues:
    blockDim: 2
    totalLength: 256
    blockLength: 128
    tileLength: 64

完成后明确告诉我实际调用的 MCP 服务器名、工具名，以及 MCP App 是否成功显示。
```

## 安全说明

- Token 只保存在当前 macOS 用户的系统钥匙串中。
- Codex 配置文件不保存 Token，只保存读取钥匙串的认证程序路径。
- 安装程序不会关闭 HTTPS 证书校验。
- 怀疑 Token 泄露时，立即联系管理员撤销并重新发放。
- 此安装方式不适用于 ChatGPT 网页版。


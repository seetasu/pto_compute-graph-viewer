#!/bin/bash

set -u
umask 077
PATH="/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:$HOME/.local/bin"
export PATH

SERVER_NAME="ascend_tiling_visualizer_cloud"
MCP_URL="https://42.192.111.92/mcp"
HEALTH_URL="https://42.192.111.92/healthz"
KEYCHAIN_SERVICE="ascend_tiling_visualizer_cloud"
HELPER_DIR="$HOME/.local/bin"
HELPER_PATH="$HELPER_DIR/ascend-tiling-mcp-auth"
CONFIG_DIR="$HOME/.codex"
CONFIG_FILE="$CONFIG_DIR/config.toml"
TEMP_HELPER=""
TEMP_CONFIG=""
TOKEN=""

pause_before_exit() {
  if [[ -t 0 ]]; then
    printf '\n按回车键关闭窗口。'
    IFS= read -r _
  fi
}

cleanup() {
  TOKEN=""
  unset TOKEN
  if [[ -n "$TEMP_HELPER" && -f "$TEMP_HELPER" ]]; then
    rm -f "$TEMP_HELPER"
  fi
  if [[ -n "$TEMP_CONFIG" && -f "$TEMP_CONFIG" ]]; then
    rm -f "$TEMP_CONFIG"
  fi
}

fail() {
  printf '\n安装未完成：%s\n' "$1" >&2
  pause_before_exit
  exit 1
}

trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

if [[ "$(uname -s)" != "Darwin" ]]; then
  fail "此安装程序仅支持 macOS。"
fi

for required_command in /usr/bin/security /usr/bin/curl /usr/bin/grep /usr/bin/awk /usr/bin/id /usr/bin/sed; do
  if [[ ! -x "$required_command" ]]; then
    fail "系统缺少必要命令：$required_command"
  fi
done

ACCOUNT=$(/usr/bin/id -un) || fail "无法读取当前 macOS 用户名。"

printf '%s\n' \
  "Ascend Tiling Visualizer MCP 安装程序" \
  "" \
  "服务：$SERVER_NAME" \
  "地址：$MCP_URL" \
  "" \
  "接下来钥匙串会提示输入密码。请粘贴管理员单独发给你的个人 Token。" \
  "输入过程不会显示字符，这是正常现象。"

# Keeping -w as the final option makes the macOS security tool prompt for the
# secret instead of exposing it as a command-line argument.
if ! /usr/bin/security add-generic-password \
  -a "$ACCOUNT" \
  -s "$KEYCHAIN_SERVICE" \
  -l "Ascend Tiling Visualizer Cloud Token" \
  -U \
  -w; then
  fail "Token 没有保存到 macOS 钥匙串。"
fi

TOKEN=$(/usr/bin/security find-generic-password \
  -a "$ACCOUNT" \
  -s "$KEYCHAIN_SERVICE" \
  -w 2>/dev/null) || fail "无法从 macOS 钥匙串读取刚保存的 Token。"

if ! /usr/bin/printf '%s' "$TOKEN" | /usr/bin/grep -Eq '^atv_[A-Za-z0-9_-]+_[A-Za-z0-9_-]{20,}$'; then
  fail "Token 格式不正确。请确认复制了完整的个人 Token，然后重新运行安装程序。"
fi

HEALTH_RESPONSE=$(/usr/bin/curl -q \
  --silent \
  --show-error \
  --connect-timeout 10 \
  --max-time 20 \
  "$HEALTH_URL") || fail "无法连接云服务，或 HTTPS 证书校验失败。"

if ! /usr/bin/printf '%s' "$HEALTH_RESPONSE" | /usr/bin/grep -q '"service":"ascend-tiling-visualizer"'; then
  fail "云服务健康检查返回了意外内容。"
fi

# curl reads the Authorization header from stdin so the Token does not appear
# in the process command line. This server returns 400 for an authenticated GET
# without an MCP session ID; 401/403 means the credential was rejected.
HTTP_CODE=$(
  /usr/bin/printf 'Authorization: Bearer %s\n' "$TOKEN" |
    /usr/bin/curl -q \
      --silent \
      --show-error \
      --output /dev/null \
      --write-out '%{http_code}' \
      --connect-timeout 10 \
      --max-time 20 \
      --header @- \
      "$MCP_URL"
)
CURL_STATUS=$?

if [[ $CURL_STATUS -ne 0 ]]; then
  fail "连接 MCP 服务失败。请检查网络后重新运行。"
fi

case "$HTTP_CODE" in
  400)
    ;;
  401|403)
    fail "Token 无效、已被停用或已过期。请联系管理员重新发放。"
    ;;
  *)
    fail "MCP 服务返回了意外状态码 $HTTP_CODE。"
    ;;
esac

mkdir -p "$HELPER_DIR" || fail "无法创建认证程序目录：$HELPER_DIR"
TEMP_HELPER=$(mktemp "$HELPER_DIR/.ascend-tiling-mcp-auth.XXXXXX") || fail "无法创建临时认证程序。"

/usr/bin/printf '%s\n' \
  '#!/bin/zsh' \
  'set -euo pipefail' \
  'account=$(/usr/bin/id -un)' \
  'token=$(/usr/bin/security find-generic-password -a "$account" -s "ascend_tiling_visualizer_cloud" -w)' \
  'trap '\''unset token account'\'' EXIT' \
  'if ! /usr/bin/printf '\''%s'\'' "$token" | /usr/bin/grep -Eq '\''^atv_[A-Za-z0-9_-]+_[A-Za-z0-9_-]{20,}$'\''; then' \
  '  /usr/bin/printf '\''Token format is invalid.\n'\'' >&2' \
  '  exit 1' \
  'fi' \
  '/usr/bin/printf '\''{"Authorization":"Bearer %s"}\n'\'' "$token"' \
  > "$TEMP_HELPER" || fail "无法写入认证程序。"

chmod 700 "$TEMP_HELPER" || fail "无法设置认证程序权限。"
mv "$TEMP_HELPER" "$HELPER_PATH" || fail "无法安装认证程序。"
TEMP_HELPER=""

mkdir -p "$CONFIG_DIR" || fail "无法创建 Codex 配置目录：$CONFIG_DIR"
TIMESTAMP=$(date '+%Y%m%d-%H%M%S')
BACKUP_FILE=""

if [[ -f "$CONFIG_FILE" ]]; then
  BACKUP_FILE="$CONFIG_FILE.backup-$TIMESTAMP"
  cp -p "$CONFIG_FILE" "$BACKUP_FILE" || fail "无法备份现有 Codex 配置。"
fi

TEMP_CONFIG=$(mktemp "$CONFIG_DIR/.config.toml.XXXXXX") || fail "无法创建临时 Codex 配置。"

if [[ -f "$CONFIG_FILE" ]]; then
  /usr/bin/awk \
    -v target="[mcp_servers.$SERVER_NAME]" \
    -v child_prefix="[mcp_servers.$SERVER_NAME." '
      BEGIN { skipping = 0 }
      {
        line = $0
        sub(/\r$/, "", line)
        if (line == target) {
          skipping = 1
          next
        }
        if (skipping && substr(line, 1, 1) == "[") {
          if (index(line, child_prefix) == 1) next
          skipping = 0
        }
        if (!skipping) print $0
      }
    ' "$CONFIG_FILE" > "$TEMP_CONFIG" || fail "无法更新现有 Codex 配置。"
fi

ESCAPED_HELPER_PATH=$(/usr/bin/printf '%s' "$HELPER_PATH" | /usr/bin/sed 's/\\/\\\\/g; s/"/\\"/g')

/usr/bin/printf '\n[mcp_servers.%s]\nurl = "%s"\nhttp_headers_helper = "%s"\nenabled = true\n' \
  "$SERVER_NAME" \
  "$MCP_URL" \
  "$ESCAPED_HELPER_PATH" \
  >> "$TEMP_CONFIG" || fail "无法写入 MCP 配置。"

chmod 600 "$TEMP_CONFIG" || fail "无法设置 Codex 配置权限。"
mv "$TEMP_CONFIG" "$CONFIG_FILE" || fail "无法安装 Codex 配置。"
TEMP_CONFIG=""

CODEX_BIN=$(command -v codex 2>/dev/null || true)
if [[ -n "$CODEX_BIN" ]]; then
  if ! "$CODEX_BIN" mcp get "$SERVER_NAME" >/dev/null 2>&1; then
    if [[ -n "$BACKUP_FILE" && -f "$BACKUP_FILE" ]]; then
      cp -p "$BACKUP_FILE" "$CONFIG_FILE"
    else
      mv "$CONFIG_FILE" "$CONFIG_FILE.failed-$TIMESTAMP"
    fi
    fail "Codex 无法读取新配置；原配置已恢复。"
  fi
fi

TOKEN=""
unset TOKEN

printf '\n%s\n' \
  "✓ 个人 Token 已保存到 macOS 钥匙串" \
  "✓ Token 已通过云服务验证" \
  "✓ MCP 认证程序已安装：$HELPER_PATH" \
  "✓ Codex MCP 配置已完成：$SERVER_NAME" \
  "" \
  "请完全退出 Codex（Command + Q），重新打开后新建一个任务。"

pause_before_exit
